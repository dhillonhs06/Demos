package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradleDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(GradleDemo1Application.class, args);
		System.out.println("Hello Gradle Project");
	}

}
